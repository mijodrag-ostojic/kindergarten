export enum TipGrupe {

    JUNIOR, JASLICE, PREDSKOLSKO
}
