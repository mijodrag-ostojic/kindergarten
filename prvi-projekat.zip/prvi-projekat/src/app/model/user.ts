export class User {

    constructor(

        public username : string | undefined,
        public password: string | undefined
    ){}

}