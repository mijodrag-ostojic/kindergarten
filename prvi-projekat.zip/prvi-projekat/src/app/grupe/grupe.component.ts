import { Component, OnInit } from '@angular/core';
import { TimeInterval } from 'rxjs/internal/operators/timeInterval';
import { TipGrupe } from '../model/tip-grupe';

@Component({
  selector: 'app-grupe',
  templateUrl: './grupe.component.html',
  styleUrls: ['./grupe.component.css']
})
export class GrupeComponent implements OnInit {

  grupe = [
    {
      imeGrupe : "Speak up",
      tipGrupe : TipGrupe.JASLICE,
      opis : 'Grupa namenjena najmladjim malisanima koji jos nisu progovorili. ',
      pocetakRada : new Date(),
      pocetakUpisa : new Date()
    },
    {
      imeGrupe : "Juniors",
      tipGrupe : TipGrupe.JUNIOR,
      opis : 'Grupa namenjena malisanima od 2 do 3 godine. ',
      pocetakRada : new Date(),
      pocetakUpisa : new Date()
    },
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
