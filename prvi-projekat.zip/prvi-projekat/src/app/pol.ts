export enum Pol {
    MALE, FEMALE, OTHER
}