import { Osoba } from './osoba';

describe('Osoba', () => {
  it('should create an instance', () => {
    expect(new Osoba()).toBeTruthy();
  });
});
